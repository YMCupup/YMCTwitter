//
//  YMCMainViewController.m
//  YMCTwitter
//
//  Created by YMC on 2020/1/14.
//  Copyright © 2020 YMC. All rights reserved.
//

#import "YMCMainViewController.h"
#import "GKNavigationBarViewController.h"

#import "ZFPlayer.h"
#import "ZFAVPlayerManager.h"
#import "ZFPlayerControlView.h"
#import "YVideoTwitterTableViewCell.h"


#import "T1StatusLayout.h"
#import "T1StatusCell.h"
#import "YYTableView.h"
#import "YYPhotoGroupView.h"
#import "YYSimpleWebViewController.h"


@interface YMCMainViewController ()<UITableViewDelegate, UITableViewDataSource, T1StatusCellDelegate ,ZFPlayerControlViewDelegate , ZFTableViewCellDelegate>
@property (nonatomic, strong) NSMutableArray *layouts;
@property (nonatomic, strong) UITableView *tableView;


//视频相关
@property (nonatomic, strong) ZFPlayerController *player;
@property (nonatomic, strong) ZFPlayerControlView *controlView;

@end

@implementation YMCMainViewController

- (instancetype)init {
    self = [super init];
    _tableView = [YYTableView new];
    _tableView.delegate = self;
    _tableView.dataSource = self;
    return self;
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    self.view.backgroundColor = [UIColor whiteColor];
}

- (void)viewWillDisappear:(BOOL)animated{
    [super viewWillDisappear:animated];
    [self.player stopCurrentPlayingCell];
}


- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor whiteColor];
    self.title = @"MainVC";
    
    
    self.view.backgroundColor = [UIColor colorWithWhite:1.000 alpha:0.919];
    
    if ([self respondsToSelector:@selector( setAutomaticallyAdjustsScrollViewInsets:)]) {
        self.automaticallyAdjustsScrollViewInsets = NO;
    }
    
    _tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 0 , kScreenWidth, self.view.height) style:UITableViewStylePlain];
    _tableView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    _tableView.delegate = self;
    _tableView.dataSource = self;
    _tableView.showsVerticalScrollIndicator = NO;
    _tableView.scrollIndicatorInsets = _tableView.contentInset;
    [_tableView  setSeparatorStyle:UITableViewCellSeparatorStyleNone];
    _tableView.backgroundColor = [UIColor clearColor];
    _tableView.backgroundView.backgroundColor = [UIColor clearColor];
    [_tableView registerClass:[T1StatusCell class] forCellReuseIdentifier:@"T1StatusCell"];
    [self.tableView registerClass:[YVideoTwitterTableViewCell class] forCellReuseIdentifier:@"YVideoTwitterTableViewCell"];
    
    [self.view addSubview:_tableView];
    
    if (@available(iOS 11.0,*)) {
        self.tableView.estimatedRowHeight = 0;
        self.tableView.estimatedSectionHeaderHeight = 0;
        self.tableView.estimatedSectionFooterHeight = 0;
    }
    
    /// 停止的时候找出最合适的播放
    @weakify(self)
    _tableView.zf_scrollViewDidStopScrollCallback = ^(NSIndexPath * _Nonnull indexPath) {
       @strongify(self)
       if (!self.player.playingIndexPath) {
           [self playTheVideoAtIndexPath:indexPath scrollToTop:NO];
       }
    };
    [self setvideoview];
    
    
    self.navigationController.view.userInteractionEnabled = NO;
    UIActivityIndicatorView *indicator = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleWhiteLarge];
    indicator.size = CGSizeMake(80, 80);
    indicator.center = CGPointMake(self.view.width / 2, self.view.height / 2);
    indicator.backgroundColor = [UIColor colorWithWhite:0.000 alpha:0.670];
    indicator.clipsToBounds = YES;
    indicator.layer.cornerRadius = 6;
    [indicator startAnimating];
    [self.view addSubview:indicator];
    
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
    NSMutableArray *layouts = [NSMutableArray new];
        NSData *data = [NSData dataNamed:[NSString stringWithFormat:@"twitter_%d.json",0]];
        T1APIRespose *response = [T1APIRespose modelWithJSON:data];
    for (int i = 0;i < response.timelineItmes.count ; i ++) {
            id item = response.timelineItmes[i];
            if ([item isKindOfClass:[T1Tweet class]]) {
                T1Tweet *tweet = item;
                if (( i %4 ) == 0 && tweet.medias.count == 0){ //此处随机选择cell显示视频,并且视频和图片不共存
                    tweet.video_url =  @"http:\/\/tb-video.bdstatic.com\/tieba-smallvideo-transcode\/20985849_722f981a5ce0fc6d2a5a4f40cb0327a5_3.mp4";
                    tweet.thumbnail_url = @"http:\/\/imgsrc.baidu.com\/forum\/eWH%3D640%2C360\/sign=265d1891f11f4134f25d7873132ba5e6\/4e4a20a4462309f7101128607e0e0cf3d7cad642.jpg";
                }
                T1StatusLayout *layout = [T1StatusLayout new];
                layout.tweet = tweet;
                [layouts addObject:layout];
            } else if ([item isKindOfClass:[T1Conversation class]]) {
                T1Conversation *conv = item;
                NSMutableArray *convLayouts = [NSMutableArray new];
                for (T1Tweet *tweet in conv.tweets) {
                    T1StatusLayout *layout = [T1StatusLayout new];
                    layout.conversation = conv;
                    layout.tweet = tweet;
                    [convLayouts addObject:layout];
                }
                if (conv.targetCount > 0 && convLayouts.count >= 2) {
                    T1StatusLayout *split = [T1StatusLayout new];
                    split.conversation = conv;
                    [split layout];
                    [convLayouts insertObject:split atIndex:1];
                }
                [layouts addObjectsFromArray:convLayouts];
            }
    }
        
//    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
//        NSMutableArray *layouts = [NSMutableArray new];
//        for (int i = 0; i <= 3; i++) {
//            NSData *data = [NSData dataNamed:[NSString stringWithFormat:@"twitter_%d.json",i]];
//            T1APIRespose *response = [T1APIRespose modelWithJSON:data];
//            for (id item in response.timelineItmes) {
//                if ([item isKindOfClass:[T1Tweet class]]) {
//                    T1Tweet *tweet = item;
//                    T1StatusLayout *layout = [T1StatusLayout new];
//                    layout.tweet = tweet;
//                    [layouts addObject:layout];
//                } else if ([item isKindOfClass:[T1Conversation class]]) {
//                    T1Conversation *conv = item;
//                    NSMutableArray *convLayouts = [NSMutableArray new];
//                    for (T1Tweet *tweet in conv.tweets) {
//                        T1StatusLayout *layout = [T1StatusLayout new];
//                        layout.conversation = conv;
//                        layout.tweet = tweet;
//                        [convLayouts addObject:layout];
//                    }
//                    if (conv.targetCount > 0 && convLayouts.count >= 2) {
//                        T1StatusLayout *split = [T1StatusLayout new];
//                        split.conversation = conv;
//                        [split layout];
//                        [convLayouts insertObject:split atIndex:1];
//                    }
//                    [layouts addObjectsFromArray:convLayouts];
//                }
//            }
//        }
        
        dispatch_async(dispatch_get_main_queue(), ^{
            self.title = [NSString stringWithFormat:@"YMCTwitter (loaded:%d)", (int)layouts.count];
            [indicator removeFromSuperview];
            self.navigationController.view.userInteractionEnabled = YES;
            self.layouts = layouts;
            [_tableView reloadData];
        });
    });
}


- (void)setvideoview{
    
    ZFAVPlayerManager *playerManager = [[ZFAVPlayerManager alloc] init];
    //    KSMediaPlayerManager *playerManager = [[KSMediaPlayerManager alloc] init];
    //    ZFIJKPlayerManager *playerManager = [[ZFIJKPlayerManager alloc] init];
    
    /// player,tag值必须在cell里设置
    self.player = [ZFPlayerController playerWithScrollView:self.tableView playerManager:playerManager containerViewTag:100];
    self.player.controlView = self.controlView;
    /// 1.0是消失100%时候
    self.player.playerDisapperaPercent = 0.8;
    /// 播放器view露出一半时候开始播放
    self.player.playerApperaPercent = .5;
    
    @weakify(self)
    self.player.playerDidToEnd = ^(id  _Nonnull asset) {
        @strongify(self)
        [self.player stopCurrentPlayingCell];
    };
    
    self.player.orientationWillChange = ^(ZFPlayerController * _Nonnull player, BOOL isFullScreen) {
        @strongify(self)
        [self setNeedsStatusBarAppearanceUpdate];
        [UIViewController attemptRotationToDeviceOrientation];
        self.tableView.scrollsToTop = !isFullScreen;
    };
    
}



- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return _layouts.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    T1StatusLayout * layout = _layouts[indexPath.row];
        T1Tweet *tweet = layout.displayedTweet;
        if (tweet.video_url.length > 0){
            YVideoTwitterTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"YVideoTwitterTableViewCell"];
            if (!cell) {
                cell = [[YVideoTwitterTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"YVideoTwitterTableViewCell"];
            }
            cell.index = indexPath;
            [cell setDelegate:self withIndexPath:indexPath];
    //        cell.delegate = self;
            [cell setLayout:_layouts[indexPath.row]];
            return cell;
        }else{
            NSString *cellID = @"cell";
            T1StatusCell *cell = [tableView dequeueReusableCellWithIdentifier:cellID];
            if (!cell) {
                cell = [[T1StatusCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellID];
                cell.delegate = self;
            }
            cell.index = indexPath;
            [cell setLayout:_layouts[indexPath.row]];
            return cell;
        }
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return ((T1StatusLayout *)_layouts[indexPath.row]).height;
}

- (BOOL)tableView:(UITableView *)tableView shouldHighlightRowAtIndexPath:(NSIndexPath *)indexPath {
    return NO;
}


#pragma mark - T1StatusCellDelegate

- (void)cell:(T1StatusCell *)cell didClickInLabel:(YYLabel *)label textRange:(NSRange)textRange {
    YYTextHighlight *highlight = [label.textLayout.text attribute:YYTextHighlightAttributeName atIndex:textRange.location];
    NSDictionary *info = highlight.userInfo;
    NSURL *link = nil;
    NSString *linkTitle = nil;
    if (info[@"T1URL"]) {
        T1URL *url = info[@"T1URL"];
        if (url.expandedURL.length) {
            link = [NSURL URLWithString:url.expandedURL];
            linkTitle = url.displayURL;
        }
    } else if (info[@"T1Media"]) {
        T1Media *media = info[@"T1Media"];
        if (media.expandedURL.length) {
            link = [NSURL URLWithString:media.expandedURL];
            linkTitle = media.displayURL;
        }
    }
    if (link) {
        YYSimpleWebViewController *vc = [[YYSimpleWebViewController alloc] initWithURL:link];
        vc.title = linkTitle;
        [self.navigationController pushViewController:vc animated:YES];
    }
}

- (void)cell:(T1StatusCell *)cell didClickImageAtIndex:(NSUInteger)index withLongPress:(BOOL)longPress {
    if (longPress) {
        // show alert
        return;
    }
    UIImageView *fromView = nil;
    NSMutableArray *items = [NSMutableArray new];
    NSArray<T1Media *> *images = cell.layout.images;
    
    for (NSUInteger i = 0, max = images.count; i < max; i++) {
        UIImageView *imgView = cell.statusView.mediaView.imageViews[i];
        T1Media *img = images[i];
        YYPhotoGroupItem *item = [YYPhotoGroupItem new];
        item.thumbView = imgView;
        item.largeImageURL = img.mediaLarge.url;
        item.largeImageSize = img.mediaLarge.size;
        [items addObject:item];
        if (i == index) {
            fromView = imgView;
        }
    }
    
    YYPhotoGroupView *v = [[YYPhotoGroupView alloc] initWithGroupItems:items];
    [v presentFromImageView:fromView toContainer:self.navigationController.view animated:YES completion:nil];
}

- (void)cell:(T1StatusCell *)cell didClickQuoteWithLongPress:(BOOL)longPress {
    
}

- (void)cell:(T1StatusCell *)cell didClickAvatarWithLongPress:(BOOL)longPress {
    
}

- (void)cell:(T1StatusCell *)cell didClickContentWithLongPress:(BOOL)longPress {
    
}

- (void)cellDidClickReply:(T1StatusCell *)cell {
    
}

- (void)cellDidClickRetweet:(T1StatusCell *)cell {
    T1StatusLayout *layout = cell.layout;
    T1Tweet *tweet = layout.displayedTweet;
    if (tweet.retweeted) {
        tweet.retweeted = NO;
        if (tweet.retweetCount > 0) tweet.retweetCount--;
        layout.retweetCountTextLayout = [layout retweetCountTextLayoutForTweet:tweet];
    } else {
        tweet.retweeted = YES;
        tweet.retweetCount++;
        layout.retweetCountTextLayout = [layout retweetCountTextLayoutForTweet:tweet];
    }
    [cell.statusView.inlineActionsView updateRetweetWithAnimation];
}

- (void)cellDidClickFavorite:(T1StatusCell *)cell {
    T1StatusLayout *layout = cell.layout;
    T1Tweet *tweet = layout.displayedTweet;
    if (tweet.favorited) {
        tweet.favorited = NO;
        if (tweet.favoriteCount > 0) tweet.favoriteCount--;
        layout.favoriteCountTextLayout = [layout favoriteCountTextLayoutForTweet:tweet];
    } else {
        tweet.favorited = YES;
        tweet.favoriteCount++;
        layout.favoriteCountTextLayout = [layout favoriteCountTextLayoutForTweet:tweet];
    }
    [cell.statusView.inlineActionsView updateFavouriteWithAnimation];
}

- (void)cellDidClickFollow:(T1StatusCell *)cell {
    T1StatusLayout *layout = cell.layout;
    T1Tweet *tweet = layout.displayedTweet;
    tweet.user.following = !tweet.user.following;
    [cell.statusView.inlineActionsView updateFollowWithAnimation];
}



- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    /// 如果正在播放的index和当前点击的index不同，则停止当前播放的index
    if (self.player.playingIndexPath != indexPath) {
        [self.player stopCurrentPlayingCell];
    }
    /// 如果没有播放，则点击进详情页会自动播放
    if (!self.player.currentPlayerManager.isPlaying) {
        [self playTheVideoAtIndexPath:indexPath scrollToTop:NO];
    }
    /// 到详情页
}


#pragma mark - 视频相关
- (void)scrollViewWillBeginDragging:(UIScrollView *)scrollView {
    [scrollView zf_scrollViewWillBeginDragging];
}

- (void)scrollViewDidEndDragging:(UIScrollView *)scrollView willDecelerate:(BOOL)decelerate {
    [scrollView zf_scrollViewDidEndDraggingWillDecelerate:decelerate];

}

- (void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView {
    [scrollView zf_scrollViewDidEndDecelerating];

}

- (void)scrollViewDidScrollToTop:(UIScrollView *)scrollView {
    [scrollView zf_scrollViewDidScrollToTop];

}

- (void)scrollViewDidScroll:(UIScrollView *)scrollView {
    [scrollView zf_scrollViewDidScroll];
}

- (BOOL)shouldAutorotate {
    return self.player.shouldAutorotate;
}

- (UIInterfaceOrientationMask)supportedInterfaceOrientations {
    if (self.player.isFullScreen && self.player.orientationObserver.fullScreenMode == ZFFullScreenModeLandscape) {
        return UIInterfaceOrientationMaskLandscape;
    }
    return UIInterfaceOrientationMaskPortrait;
}

- (UIStatusBarStyle)preferredStatusBarStyle {
    if (self.player.isFullScreen) {
        return UIStatusBarStyleLightContent;
    }
    return UIStatusBarStyleDefault;
}

- (BOOL)prefersStatusBarHidden {
    /// 如果只是支持iOS9+ 那直接return NO即可，这里为了适配iOS8
    return self.player.isStatusBarHidden;
}


- (UIStatusBarAnimation)preferredStatusBarUpdateAnimation {
    return UIStatusBarAnimationSlide;
}

#pragma mark - ZFTableViewCellDelegate

- (void)zf_playTheVideoAtIndexPath:(NSIndexPath *)indexPath {
    [self playTheVideoAtIndexPath:indexPath scrollToTop:NO];
}

#pragma mark - private method

/// play the video
- (void)playTheVideoAtIndexPath:(NSIndexPath *)indexPath scrollToTop:(BOOL)scrollToTop {
    T1StatusLayout * layout = _layouts[indexPath.row];
    
    T1Tweet *tweet = layout.displayedTweet;
        [self.player playTheIndexPath:indexPath assetURL:[NSURL URLWithString:tweet.video_url]
                          scrollToTop:scrollToTop];
        self.player.currentPlayerManager.volume = 0;
        [self.controlView showTitle:tweet.text
                     coverURLString:tweet.video_url
                     fullScreenMode:ZFFullScreenModeAutomatic];
}


- (ZFPlayerControlView *)controlView {
    if (!_controlView) {
        _controlView = [ZFPlayerControlView new];
        _controlView.fastViewAnimated = YES;
        _controlView.fullScreenOnly = YES;
        _controlView.horizontalPanShowControlView = NO;
        _controlView.prepareShowLoading = YES;
        _controlView.delegate = self;
    }
    return _controlView;
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
