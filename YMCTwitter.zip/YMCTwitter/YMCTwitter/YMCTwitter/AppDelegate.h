//
//  AppDelegate.h
//  YMCTwitter
//
//  Created by YMC on 2020/1/14.
//  Copyright © 2020 YMC. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>
@property (strong, nonatomic) UIWindow *window;
@end

