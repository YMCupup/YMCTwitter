//
//  GKPushTransitionAnimation.h
//  GKNavigationBarViewController
//
//  Created by QuintGao on 2017/7/10.
//  Copyright © 2017年 高坤. All rights reserved.
//

#import "GKBaseTransitionAnimation.h"

@interface GKPushTransitionAnimation : GKBaseTransitionAnimation

@end
