//
//  YMCMainViewController.h
//  YMCTwitter
//
//  Created by YMC on 2020/1/14.
//  Copyright © 2020 YMC. All rights reserved.
//

#import <UIKit/UIKit.h>
NS_ASSUME_NONNULL_BEGIN

@interface YMCMainViewController : UIViewController

@end

NS_ASSUME_NONNULL_END
