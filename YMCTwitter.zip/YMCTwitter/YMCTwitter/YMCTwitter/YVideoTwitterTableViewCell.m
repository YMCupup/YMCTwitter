//
//  YVideoTwitterTableViewCell.m
//  GameChatPro
//
//  Created by YMC on 2019/12/17.
//  Copyright © 2019 YMC. All rights reserved.
//

#import "YVideoTwitterTableViewCell.h"
#import "ZFTableData.h"
#import "UIImageView+ZFCache.h"
#import <AVFoundation/AVFoundation.h>

@interface YVideoTwitterTableViewCell ()
@property (nonatomic, strong) UIImageView *coverImageView;
@property (nonatomic, strong) UIView *fullMaskView;
@property (nonatomic, strong) UIButton *playBtn;
@property (nonatomic, strong) UILabel *titleLabel;
@property (nonatomic, weak) id<ZFTableViewCellDelegate> delegate;
@property (nonatomic, strong) NSIndexPath *indexPath;
@property (nonatomic, strong) UIImageView *bgImgView;

@property (nonatomic, strong) UIView *effectView;


@property (nonatomic, strong) UIImageView *retweetcoverImageView;
@property (nonatomic, strong) UIButton *retweetplayBtn;
@property (nonatomic, strong) UILabel *timeLabel;
@end
@implementation YVideoTwitterTableViewCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        [self.contentView addSubview:self.bgImgView];
        [self.bgImgView addSubview:self.effectView];
        [self.contentView addSubview:self.coverImageView];
        [self.coverImageView addSubview:self.playBtn];
        [self.contentView addSubview:self.fullMaskView];

        
        self.coverImageView.left = self.statusView.nameLabel.left;
        self.coverImageView.height = kT1ContentWidth * (10.0 / 16.0);
        self.coverImageView.width = kT1ContentWidth;
        
        

//        self.contentView.backgroundColor = [UIColor blackColor];
        self.selectionStyle = UITableViewCellSelectionStyleNone;
    
    }
    return self;
}

- (void)setZflayout:(ZFTableViewCellLayout *)zflayout{
    _zflayout = zflayout;

}


- (void)setDelegate:(id<ZFTableViewCellDelegate>)delegate withIndexPath:(NSIndexPath *)indexPath {
    self.delegate = delegate;
    self.indexPath = indexPath;
}

- (void)setNormalMode {
    self.fullMaskView.hidden = YES;
//    self.contentView.backgroundColor = [UIColor whiteColor];
}

- (void)showMaskView {
    [UIView animateWithDuration:0.3 animations:^{
        self.fullMaskView.alpha = 1;
    }];
}

- (void)hideMaskView {
    [UIView animateWithDuration:0.3 animations:^{
        self.fullMaskView.alpha = 0;
    }];
}


- (void)playBtnClick:(UIButton *)sender {
    if ([self.delegate respondsToSelector:@selector(zf_playTheVideoAtIndexPath:)]) {
        [self.delegate zf_playTheVideoAtIndexPath:self.indexPath];
    }
}

#pragma mark - getter

- (UIButton *)playBtn {
    if (!_playBtn) {
        _playBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        [_playBtn setImage:[UIImage imageNamed:@"PCshipinganniu"] forState:UIControlStateNormal];
        [_playBtn addTarget:self action:@selector(playBtnClick:) forControlEvents:UIControlEventTouchUpInside];
    }
    return _playBtn;
}

- (UIButton *)retweetplayBtn {
    if (!_retweetplayBtn) {
        _retweetplayBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        [_retweetplayBtn setImage:[UIImage imageNamed:@"PCshipinganniu"] forState:UIControlStateNormal];
        [_retweetplayBtn addTarget:self action:@selector(playBtnClick:) forControlEvents:UIControlEventTouchUpInside];
    }
    return _retweetplayBtn;
}


- (UIView *)fullMaskView {
    if (!_fullMaskView) {
        _fullMaskView = [UIView new];
        _fullMaskView.backgroundColor = [[UIColor blackColor] colorWithAlphaComponent:0.8];
        _fullMaskView.userInteractionEnabled = NO;
    }
    return _fullMaskView;
}




- (UIImageView *)coverImageView {
    if (!_coverImageView) {
        _coverImageView = [[UIImageView alloc] init];
        _coverImageView.userInteractionEnabled = YES;
        _coverImageView.tag = 100;
        _coverImageView.contentMode = UIViewContentModeScaleToFill;
    }
    return _coverImageView;
}

- (UIImageView *)retweetcoverImageView {
    if (!_retweetcoverImageView) {
        _retweetcoverImageView = [[UIImageView alloc] init];
        _retweetcoverImageView.userInteractionEnabled = YES;
        _retweetcoverImageView.tag = 100;
        _retweetcoverImageView.contentMode = UIViewContentModeScaleToFill;
    }
    return _retweetcoverImageView;
}



- (UIImageView *)bgImgView {
    if (!_bgImgView) {
        _bgImgView = [[UIImageView alloc] init];
        _bgImgView.userInteractionEnabled = YES;
    }
    return _bgImgView;
}

- (UIView *)effectView {
    if (!_effectView) {
        if (@available(iOS 8.0, *)) {
            UIBlurEffect *effect = [UIBlurEffect effectWithStyle:UIBlurEffectStyleDark];
            _effectView = [[UIVisualEffectView alloc] initWithEffect:effect];
        } else {
            UIToolbar *effectView = [[UIToolbar alloc] init];
            effectView.barStyle = UIBarStyleBlackTranslucent;
            _effectView = effectView;
        }
    }
    return _effectView;
}

- (void)setLayout:(T1StatusLayout *)layout {
    [super setLayout:layout];
    
    self.coverImageView.layer.cornerRadius = 7;
    self.coverImageView.layer.masksToBounds = YES;
    
    
    self.coverImageView.top = layout.imagesTop;

   
    self.playBtn.left = kT1ContentWidth / 2 - 22.5;
    self.playBtn.top = kT1ContentWidth * (10.0 / 16.0) / 2 - 22.5;
    self.playBtn.width = 45;
    self.playBtn.height = 45;

    [self.coverImageView setImageWithURLString:layout.tweet.thumbnail_url placeholder:[UIImage imageNamed:@"novideoimg"]];
}




@end
