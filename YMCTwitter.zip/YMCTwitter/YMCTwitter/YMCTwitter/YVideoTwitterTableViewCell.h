//
//  YVideoTwitterTableViewCell.h
//  GameChatPro
//
//  Created by YMC on 2019/12/17.
//  Copyright © 2019 YMC. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "T1StatusCell.h"
#import "ZFTableViewCellLayout.h"
NS_ASSUME_NONNULL_BEGIN
@protocol ZFTableViewCellDelegate <NSObject>

- (void)zf_playTheVideoAtIndexPath:(NSIndexPath *)indexPath;

@end

@interface YVideoTwitterTableViewCell : T1StatusCell


@property (nonatomic, strong) ZFTableViewCellLayout *zflayout;
@property (nonatomic, copy) void(^playCallback)(void);
@property (nonatomic, copy) void(^ShowHeadImage)(NSString *imageUrl);

- (void)setDelegate:(id<ZFTableViewCellDelegate>)delegate withIndexPath:(NSIndexPath *)indexPath;

- (void)showMaskView;

- (void)hideMaskView;

- (void)setNormalMode;

@end

NS_ASSUME_NONNULL_END
